export default {
    registreCoach(state,payload){
        state.coaches.push(payload);
    }
};