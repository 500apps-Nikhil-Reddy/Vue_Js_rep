import Vue from 'vue';
//import Vuex from 'vuex';
import router from './router.js';
import App from './App.vue'; 
import VueRouter from 'vue-router';
import Vuex from  './store/index.js';
import BaseCard from './components/ui/BaseCard.vue';
import BaseButton from './components/ui/BaseButton.vue';
import BaseBadge from './components/ui/BaseBadge.vue';


Vue.use(Vuex);
Vue.use(VueRouter);
Vue.component('base-card', BaseCard);
Vue.component('base-button', BaseButton);
Vue.component('base-badge', BaseBadge);

new Vue({
    el:'#app',
    Vuex,
    router : router,
    render: h => h(App)
});