<template>
  <div class="container">
    <h2>All Users</h2>
    <router-link to="/goals">Course Goals</router-link>
  </div>
</template>