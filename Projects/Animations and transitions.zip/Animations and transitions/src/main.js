import Vue from 'vue';
import VueRouter from 'vue-router';

import App from './App.vue';
import BaseModal from './components/BaseModal.vue';
import AllUsers from './pages/AllUsers.vue';
import CourseGoals from './pages/CourseGoals.vue';

const router =  new VueRouter({
  mode:'history',
  routes: [
    { path: '/', component: AllUsers },
    { path: '/goals', component: CourseGoals }
  ]
});



Vue.component('base-modal', BaseModal);

Vue.use(VueRouter);

new Vue({
    el:'#app',
    router:router,
    render: h => h(App)
});

router.isReady().then(function() {
//  Vue.mount('#app');
});


