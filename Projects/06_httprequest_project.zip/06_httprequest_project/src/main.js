import Vue from 'vue';

//import { Plugin } from "vue-fragments"; 


import BaseCard from './components/UI/BaseCard.vue';
import BaseButton from './components/UI/BaseButton.vue';
import App from './App.vue';

//Vue.use(Plugin);

Vue.component('base-card', BaseCard);
Vue.component('base-button', BaseButton);

new Vue({
    el:'#app',
    render: h => h(App)
});
