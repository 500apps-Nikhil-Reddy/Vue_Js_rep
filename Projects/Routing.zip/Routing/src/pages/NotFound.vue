<template>
  <h2>
    Page not found! Maybe view our
    <router-link to="/teams">Teams</router-link>?
  </h2>
</template>