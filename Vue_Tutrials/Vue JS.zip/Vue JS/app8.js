Vue.component('app-user',{   // we can write globally also
    data: function()
    {
        return{
            users:[
                {username:'Nik'},
                {username:'Sha'},
                {username:'Bha'}
            ]
        };
    },
    template:'<div><div class = "user" v-for = "user in users"> <p>Username :{{user.username}}</p></div></div>'

});




new Vue({
    el:"#vue-app8",
    data:{
        title:"Nikni"
         
    }
});