new Vue({
    el: '#vue-app',
    data:{
        name: 'Nikhil',
        Age : 29,
        x: 0,
        y: 0,
        website : 'https://mail.google.com/mail/u/0/?tab=cm#inbox',
        WebsiteTag : '<a v-bind:href = "website">The Net Ninja</a>'
    },
    methods:{
        test:function(time)
        {
            return 'Good' + time+' '+ this.name;
        }, 

        add: function(inc)
        {
            this.Age += inc;
        },
        substract: function(dec)
        {
            this.Age -= dec;
        },

        updateXY: function(event)
        {
            this.x = event.offsetX;
            this.y = event.offsetY;
        },
        click: function()
        {
            alert("You clicked me");
        }

    }
});