new Vue({
    el:'#vue-app2',
    data:{
        name : "",
        age : ""

    },
    methods:{
        logName: function()
        {
            console.log("You Entered Your Name");
        },
        logAge: function()
        {
            console.log("You Entered your Age");
        }
    }
})