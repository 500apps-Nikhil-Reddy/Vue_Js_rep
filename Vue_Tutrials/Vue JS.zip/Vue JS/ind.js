new Vue({
    el:'#vue-appn',
    data:{
     
         officers :[ { id: '20', name: 'Captain Piett' }, 
                     { id: '24', name: 'General Veers' },
                    { id: '56',  name: 'Admiral Ozzel'},
                    { id: '88',  name: 'Commander Jerjerrod'}
          
       ]
    },
});