new Vue({
    el:'#vue-app4',
    data:{
        available:true,
        nearby : false
    },

    computed:{
        compClasses: function()
        {
            return {
                available:this.available,
                nearby:this.nearby
            }
        }
    }
});