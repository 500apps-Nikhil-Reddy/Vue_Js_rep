new Vue({
    el:'#vue-app6',
    data:{
       name:'jack',
       characters : ['Nikhil', 'Bharath', 'Sanjay', 'Achu'],
       ninjas :[
           {name: 'Nik',age:21},
           {name: 'Bhar',age:22},
           {name: 'San',age:25},
           {name: 'Achyu',age:20},
       ]
    },
});