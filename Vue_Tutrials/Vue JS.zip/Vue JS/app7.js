Vue.filter('uppercase', funciton(value){
    return value.toUpperCase();  // we can write filters globally also
});

new Vue({
    el: '#vue-app7',
    data:{
        title:"helloworld",
        message:"something"
    },


  /*  computed:{
        theTitle: function()
        {
            return this.title.toUpperCase();
        },

        theTitle2: function()
        {
            return this.title.toLowerCase();
        }
    },*/

    filters:{   // we cam write filters locally also
        lowercase: function(value)
        {
            return value.toLowerCase();
        },
        uppercase: function(value)
        {
            return value.toUpperCase();
        } 
    }


});