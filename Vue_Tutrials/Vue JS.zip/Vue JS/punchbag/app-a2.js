new Vue({
    el:'#app-1',
    data:{
        output:'Your Favourite Food'

    },

    methods:{
        readRefs: function(){
            console.log(this.$refs.input.value);
            this.output = this.$refs.input.value;
        }
    }
});