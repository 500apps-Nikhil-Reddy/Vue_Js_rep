var one = new Vue({
    el:"#app-1",
    data:{
        name:'First Instance Property'
    },

    methods:{

    },

    computed:{
        greet: function()
        {
            return "Hello form app 1";
        }
    }

});

var two = new Vue({
    el:"#app-2",
    data:{
        name:"Second Instance Property"
    },

    methods:{
        change: function() 
        {
            one.name = "First Title Changed";
        }
    },

    computed:{
        greet: function()
        {
            return "Hello form app 2";
        }
    }
});

two.name = "Change form Outside";
