var data = {
    name:'Achu'
}

Vue.component('Message',{
        template:'<p>Hey there.., I am {{name}}.<button v-on:click = "changeName">Change Name</button></p>',
        data: function(){
             return data; /* {
                name:'Nikhil'
             }*/
        },
        methods:{
            changeName: function()
            {
                this.name = "MArio";
            }
        }
    }
);



new Vue({
    el:'#app-1',
});

new Vue({
    el:'#app-2',
   
});