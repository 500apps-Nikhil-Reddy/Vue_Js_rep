/*const buttonEl = document.querySelector('button');
const inputEl = document.querySelector('input');
const listEl = document.querySelector('ul');

buttonEl.addEventListener('click', addGoal);


function addGoal(){
    const enteredValue = inputEl.value;
    const listItemeEl = document.createElement('li');
    listItemeEl.textContent = enteredValue;
    listEl.appendChild(listItemeEl);
}*/

new Vue({
    el:'#app',
    data() {
        return{
            goals: [],
            enteredValue: ''
        };
    },

    methods:{
        addGoal() {
            this.goals.push(this.enteredValue);
            this.enteredValue = '';
        }
    }

});