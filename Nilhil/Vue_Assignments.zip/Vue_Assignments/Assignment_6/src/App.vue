<template>
  <div id="app">
    <h1>Lets start</h1>
    <router-link to="/">Hello</router-link>
    <br />
    <router-link to="/home">Home</router-link>
    <router-view></router-view>
  </div>
</template>
<script>
export default {
  data() {
    return {};
  },
};
</script>