/* eslint-disable no-unused-vars */
<template>
  <div>
    <h1>Hi, Nikhil here.</h1>
    <button @click="goHome">Go Home</button>
  </div>
</template>

<script>
export default {
  methods: {
    goHome(){
      this.$router.push('/home');
    }
  }
}
</script>