<template>
  <div>
    <app-header v-bind:title = "title" v-on:changeTitle = "updateTitle($event)"></app-header>
    <app-ninjas v-bind:ninjas = "ninjas"></app-ninjas>
    <app-footer v-bind:title = "title"></app-footer>
    
 </div>
</template>

<script>

import Header from './components/Header.vue';
import Footer from './components/Footer.vue';
import Ninjas from './components/Ninjas.vue';

export default {
    components:{
      'app-header': Header,
      'app-ninjas' : Ninjas,
      'app-footer' : Footer
      
    },
  data() {
    return {
       ninjas:[
            {name:'Nikhil', speciality:'Vue Components', show:false},
            {name:'Bharath', speciality:'HTML Wizardy', show:false},
            {name:'Ram', speciality:'Click Events', show:false},
            {name:'John', speciality:'Conditionals', show:false},
            {name:'Vicky', speciality:'Webpack', show:false},
            {name:'Tony', speciality:'Data Diggin', show:false}
        ],

        title:'Vue Ninjas'
    
    };
  },

  methods:{
    updateTitle: function(updatedTitle){
      this.title = updatedTitle;

    }
  }
};
</script>

<style>
</style>